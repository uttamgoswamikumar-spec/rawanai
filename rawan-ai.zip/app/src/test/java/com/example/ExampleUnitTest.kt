package com.example

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun math_calculation_evaluates_correctly() {
    val regex = Regex("""(\d+)\s*([\+\-\*\/])\s*(\d+)""")
    val match = regex.find("15 * 8")
    assertNotNull(match)
    val (aStr, op, bStr) = match!!.destructured
    val a = aStr.toDouble()
    val b = bStr.toDouble()
    val res = a * b
    assertEquals(120.0, res, 0.001)
  }

  @Test
  fun phone_number_regex_matches_valid_numbers() {
    val numberRegex = Regex("""(\+?\d[\d\s\-]{7,14}\d)""")
    val command = "9876543210 par call karo"
    val match = numberRegex.find(command)
    assertNotNull(match)
    assertEquals("9876543210", match!!.value)
  }

  @Test
  fun devanagari_numerals_normalization() {
    val hindiText = "९८७६५४३२१०"
    val normalized = hindiText
      .replace('०', '0')
      .replace('१', '1')
      .replace('२', '2')
      .replace('३', '3')
      .replace('४', '4')
      .replace('५', '5')
      .replace('६', '6')
      .replace('७', '7')
      .replace('८', '8')
      .replace('९', '9')
    assertEquals("9876543210", normalized)
  }
}
