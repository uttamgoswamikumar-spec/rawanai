package com.example.voice

import com.example.phone.AppControlManager
import com.example.phone.CallTarget
import com.example.phone.PhoneCallManager
import java.util.Locale

sealed class ParsedVoiceAction {
    data class CallConfirmationRequired(val target: CallTarget) : ParsedVoiceAction()
    data class LaunchApp(val appTarget: AppControlManager.AppTarget) : ParsedVoiceAction()
    data class AccessibilityNav(val actionType: AccessibilityActionType) : ParsedVoiceAction()
    data class SystemControl(val controlType: SystemControlType) : ParsedVoiceAction()
    data class ConversationalQuery(val query: String) : ParsedVoiceAction()
}

enum class AccessibilityActionType {
    HOME,
    BACK,
    RECENTS,
    NOTIFICATIONS,
    QUICK_SETTINGS,
    SCREENSHOT
}

enum class SystemControlType {
    MUTE_VOICE,
    UNMUTE_VOICE,
    STOP_SPEAKING,
    OPEN_ACCESSIBILITY_SETTINGS,
    BATTERY_CHECK,
    TIME_CHECK
}

class VoiceCommandParser(
    private val appControlManager: AppControlManager,
    private val phoneCallManager: PhoneCallManager
) {
    fun parse(command: String): ParsedVoiceAction {
        val lower = command.trim().lowercase(Locale.ROOT)

        // 1. System speech control commands
        if (lower.contains("chup raho") || lower.contains("चुप रहो") ||
            lower.contains("aawaz band karo") || lower.contains("आवाज़ बंद करो") ||
            lower.contains("mute") || lower.contains("म्यूट")
        ) {
            return ParsedVoiceAction.SystemControl(SystemControlType.MUTE_VOICE)
        }

        if (lower.contains("unmute") || lower.contains("अनम्यूट") ||
            lower.contains("aawaz chalu karo") || lower.contains("आवाज़ चालू करो")
        ) {
            return ParsedVoiceAction.SystemControl(SystemControlType.UNMUTE_VOICE)
        }

        if (lower == "ruk jao" || lower == "रुक जाओ" || lower == "stop" || lower == "स्टॉप" ||
            lower == "bas karo" || lower == "बस करो"
        ) {
            return ParsedVoiceAction.SystemControl(SystemControlType.STOP_SPEAKING)
        }

        // 2. Phone Call Commands (Must require confirmation, never silent!)
        val callKeywords = listOf(
            "call", "कॉल", "phone lagao", "फ़ोन लगाओ", "फोन लगाओ", "phone karo", "फ़ोन करो", "फोन करो"
        )
        if (callKeywords.any { lower.contains(it) }) {
            val callTarget = phoneCallManager.parseCallTarget(command)
            if (callTarget != null) {
                return ParsedVoiceAction.CallConfirmationRequired(callTarget)
            }
        }

        // 3. App Launch Commands (WhatsApp, YouTube, Chrome, Phone, Messages, Settings, etc.)
        val openKeywords = listOf("open", "खोलो", "chalao", "चलाओ", "start", "start karo", "शुरू करो", "दिखाओ")
        val appTarget = appControlManager.findAppByVoiceCommand(lower)
        if (appTarget != null) {
            // If user said "open X" or simply "WhatsApp", "YouTube", etc.
            val hasOpenKeyword = openKeywords.any { lower.contains(it) }
            val hasDirectAppKeyword = appTarget.keywords.any { lower.contains(it) }
            if (hasOpenKeyword || hasDirectAppKeyword) {
                return ParsedVoiceAction.LaunchApp(appTarget)
            }
        }

        // 4. Accessibility Screen Navigation Commands
        if (lower.contains("home screen") || lower.contains("होम स्क्रीन") ||
            lower.contains("home jao") || lower.contains("होम जाओ") || lower == "home"
        ) {
            return ParsedVoiceAction.AccessibilityNav(AccessibilityActionType.HOME)
        }

        if (lower.contains("back jao") || lower.contains("बैक जाओ") ||
            lower.contains("piche jao") || lower.contains("पीछे जाओ") || lower == "back"
        ) {
            return ParsedVoiceAction.AccessibilityNav(AccessibilityActionType.BACK)
        }

        if (lower.contains("recent apps") || lower.contains("रीसेंट ऐप्स") ||
            lower.contains("khule huye apps") || lower.contains("खुले हुए ऐप्स")
        ) {
            return ParsedVoiceAction.AccessibilityNav(AccessibilityActionType.RECENTS)
        }

        if (lower.contains("notification") || lower.contains("नोटिफिकेशन")) {
            return ParsedVoiceAction.AccessibilityNav(AccessibilityActionType.NOTIFICATIONS)
        }

        if (lower.contains("quick settings") || lower.contains("क्विक सेटिंग्स") ||
            lower.contains("control center") || lower.contains("कंट्रोल सेंटर")
        ) {
            return ParsedVoiceAction.AccessibilityNav(AccessibilityActionType.QUICK_SETTINGS)
        }

        if (lower.contains("screenshot") || lower.contains("स्क्रीनशॉट")) {
            return ParsedVoiceAction.AccessibilityNav(AccessibilityActionType.SCREENSHOT)
        }

        // 5. Default: High Knowledge / Conversational Query
        return ParsedVoiceAction.ConversationalQuery(command)
    }
}
