package com.example.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.util.Log
import com.example.data.SettingsRepository
import java.util.Locale

class RawanVoiceManager(
    private val context: Context,
    private val settingsRepository: SettingsRepository,
    private val onSpeechRecognized: (text: String) -> Unit,
    private val onPartialSpeech: (text: String) -> Unit,
    private val onRmsChanged: (rmsNormalized: Float) -> Unit,
    private val onListeningStateChanged: (isListening: Boolean) -> Unit,
    private val onSpeakingStateChanged: (isSpeaking: Boolean) -> Unit,
    private val onError: (message: String) -> Unit
) {
    private val tag = "RawanVoiceManager"
    private val mainHandler = Handler(Looper.getMainLooper())

    private var speechRecognizer: SpeechRecognizer? = null
    private var textToSpeech: TextToSpeech? = null
    private var isTtsInitialized = false
    private var isCurrentlyListening = false
    private var isCurrentlySpeaking = false
    var isMuted: Boolean = false

    init {
        initializeSpeechRecognizer()
        initializeTextToSpeech()
    }

    fun initializeSpeechRecognizer() {
        mainHandler.post {
            try {
                speechRecognizer?.destroy()
                if (SpeechRecognizer.isRecognitionAvailable(context)) {
                    speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                        setRecognitionListener(createRecognitionListener())
                    }
                } else {
                    Log.w(tag, "Speech recognition not available on this device")
                }
            } catch (e: Exception) {
                Log.e(tag, "Error initializing SpeechRecognizer", e)
            }
        }
    }

    private fun initializeTextToSpeech() {
        textToSpeech = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                isTtsInitialized = true
                configureFemaleHindiVoice()
                textToSpeech?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        mainHandler.post {
                            isCurrentlySpeaking = true
                            onSpeakingStateChanged(true)
                        }
                    }

                    override fun onDone(utteranceId: String?) {
                        mainHandler.post {
                            isCurrentlySpeaking = false
                            onSpeakingStateChanged(false)
                        }
                    }

                    override fun onError(utteranceId: String?) {
                        mainHandler.post {
                            isCurrentlySpeaking = false
                            onSpeakingStateChanged(false)
                        }
                    }
                })
            } else {
                Log.e(tag, "TTS initialization failed with status $status")
            }
        }
    }

    private fun configureFemaleHindiVoice() {
        val tts = textToSpeech ?: return
        val hindiLocale = Locale.forLanguageTag("hi-IN")
        val result = tts.setLanguage(hindiLocale)

        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            tts.setLanguage(Locale.forLanguageTag("hi"))
        }

        // Prefer female Hindi voice
        try {
            val voices: Set<Voice>? = tts.voices
            if (!voices.isNullOrEmpty()) {
                val hindiFemaleVoice = voices.firstOrNull { voice ->
                    val isHindi = voice.locale.language.equals("hi", ignoreCase = true) ||
                            voice.name.contains("hi-in", ignoreCase = true)
                    val isFemale = voice.name.contains("female", ignoreCase = true) ||
                            voice.name.contains("woman", ignoreCase = true) ||
                            voice.name.contains("hie", ignoreCase = true) ||
                            voice.features.any { it.contains("female", ignoreCase = true) }
                    isHindi && isFemale
                } ?: voices.firstOrNull { voice ->
                    voice.locale.language.equals("hi", ignoreCase = true)
                }

                if (hindiFemaleVoice != null) {
                    tts.voice = hindiFemaleVoice
                    Log.d(tag, "Selected voice: ${hindiFemaleVoice.name}")
                }
            }
        } catch (e: Exception) {
            Log.w(tag, "Error setting female voice", e)
        }

        applyVoiceSettings()
    }

    fun applyVoiceSettings() {
        val tts = textToSpeech ?: return
        val pitch = settingsRepository.getVoicePitch()
        val speed = settingsRepository.getVoiceSpeed()
        tts.setPitch(pitch)
        tts.setSpeechRate(speed)
    }

    fun startListening() {
        stopSpeaking()
        mainHandler.post {
            try {
                if (speechRecognizer == null) {
                    initializeSpeechRecognizer()
                }

                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(
                        RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                        RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
                    )
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
                    putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, false)
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                    putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
                }

                speechRecognizer?.startListening(intent)
                isCurrentlyListening = true
                onListeningStateChanged(true)
            } catch (e: Exception) {
                Log.e(tag, "Failed to start listening", e)
                isCurrentlyListening = false
                onListeningStateChanged(false)
                onError("माइक शुरू नहीं हो सका: ${e.localizedMessage}")
            }
        }
    }

    fun stopListening() {
        mainHandler.post {
            try {
                speechRecognizer?.stopListening()
            } catch (e: Exception) {
                Log.w(tag, "Error stopping listening", e)
            } finally {
                isCurrentlyListening = false
                onListeningStateChanged(false)
            }
        }
    }

    fun speak(text: String, utteranceId: String = "rawan_speech_${System.currentTimeMillis()}") {
        stopListening()
        if (isMuted) {
            // Muted mode - do not output sound, just brief state flash
            mainHandler.post {
                onSpeakingStateChanged(false)
            }
            return
        }

        mainHandler.post {
            if (!isTtsInitialized || textToSpeech == null) {
                onError("स्पीच इंजन लोड हो रहा है...")
                return@post
            }
            applyVoiceSettings()
            val params = Bundle().apply {
                putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, utteranceId)
            }
            textToSpeech?.speak(text, TextToSpeech.QUEUE_FLUSH, params, utteranceId)
        }
    }

    fun stopSpeaking() {
        mainHandler.post {
            if (isCurrentlySpeaking || textToSpeech?.isSpeaking == true) {
                textToSpeech?.stop()
                isCurrentlySpeaking = false
                onSpeakingStateChanged(false)
            }
        }
    }

    private fun createRecognitionListener(): RecognitionListener {
        return object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                isCurrentlyListening = true
                onListeningStateChanged(true)
            }

            override fun onBeginningOfSpeech() {
                // Speech started
            }

            override fun onRmsChanged(rmsdB: Float) {
                // Normalize dB to 0.0 .. 1.0 for visualizer
                val normalized = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
                onRmsChanged(normalized)
            }

            override fun onBufferReceived(buffer: ByteArray?) {}

            override fun onEndOfSpeech() {
                isCurrentlyListening = false
                onListeningStateChanged(false)
            }

            override fun onError(error: Int) {
                isCurrentlyListening = false
                onListeningStateChanged(false)
                val message = when (error) {
                    SpeechRecognizer.ERROR_AUDIO -> "ऑडियो रिकॉर्डिंग त्रुटि।"
                    SpeechRecognizer.ERROR_CLIENT -> "माइक क्लाइंट त्रुटि।"
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "माइक की अनुमति आवश्यक है।"
                    SpeechRecognizer.ERROR_NETWORK -> "इंटरनेट कनेक्शन चेक करें।"
                    SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "नेटवर्क टाइमआउट।"
                    SpeechRecognizer.ERROR_NO_MATCH -> "आवाज़ स्पष्ट नहीं सुनाई दी।"
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "स्पीच इंजन व्यस्त है, पुनः प्रयास करें।"
                    SpeechRecognizer.ERROR_SERVER -> "सर्वर त्रुटि।"
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "कोई आवाज़ नहीं मिली।"
                    else -> "त्रुटि $error"
                }
                Log.w(tag, "Speech recognition error: $error ($message)")
                if (error != SpeechRecognizer.ERROR_NO_MATCH && error != SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                    onError(message)
                }
            }

            override fun onResults(results: Bundle?) {
                isCurrentlyListening = false
                onListeningStateChanged(false)
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val heardText = matches?.firstOrNull()?.trim().orEmpty()
                if (heardText.isNotBlank()) {
                    onSpeechRecognized(heardText)
                }
            }

            override fun onPartialResults(partialResults: Bundle?) {
                val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val partial = matches?.firstOrNull().orEmpty()
                if (partial.isNotBlank()) {
                    onPartialSpeech(partial)
                }
            }

            override fun onEvent(eventType: Int, params: Bundle?) {}
        }
    }

    fun destroy() {
        try {
            speechRecognizer?.destroy()
            speechRecognizer = null
            textToSpeech?.stop()
            textToSpeech?.shutdown()
            textToSpeech = null
        } catch (e: Exception) {
            Log.e(tag, "Error destroying RawanVoiceManager", e)
        }
    }
}
