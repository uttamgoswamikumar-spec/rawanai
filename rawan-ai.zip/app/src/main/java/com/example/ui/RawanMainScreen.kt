package com.example.ui

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.VolumeMute
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.BatteryFull
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.data.MessageSender
import com.example.data.RawanMessage
import com.example.data.TelemetryData
import com.example.ui.components.CallConfirmationModal
import com.example.ui.components.HolographicAudioWaveform
import com.example.ui.components.JarvisCoreState
import com.example.ui.components.JarvisGlowingCyanOrb
import com.example.ui.components.QuickAppsModal
import com.example.ui.components.RawanSettingsDialog
import com.example.ui.components.UninstalledAppModal
import com.example.ui.theme.ArcGlow
import com.example.ui.theme.BorderCyan
import com.example.ui.theme.BorderGlow
import com.example.ui.theme.CyberBackground
import com.example.ui.theme.CyberBackgroundEnd
import com.example.ui.theme.CyberGreen
import com.example.ui.theme.CyberRed
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceCard
import com.example.ui.theme.CyberSurfaceVariant
import com.example.ui.theme.HoloAmber
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun RawanMainScreen(
    viewModel: RawanViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val context = LocalContext.current
    var showSettings by remember { mutableStateOf(false) }
    var showQuickApps by remember { mutableStateOf(false) }
    var showTextInput by remember { mutableStateOf(false) }
    var typedQuery by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    // Permissions launcher for RECORD_AUDIO and READ_CONTACTS
    val permissionsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { perms ->
        val audioGranted = perms[Manifest.permission.RECORD_AUDIO] == true
        if (audioGranted) {
            viewModel.startListening()
        } else {
            Toast.makeText(context, "माइक की अनुमति आवश्यक है!", Toast.LENGTH_SHORT).show()
        }
    }

    fun checkAndStartListening() {
        val hasAudio = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        val hasContacts = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.READ_CONTACTS
        ) == PackageManager.PERMISSION_GRANTED

        if (hasAudio && hasContacts) {
            viewModel.startListening()
        } else {
            permissionsLauncher.launch(
                arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS)
            )
        }
    }

    // Auto scroll to bottom when new messages arrive
    LaunchedEffect(uiState.messages.size) {
        if (uiState.messages.isNotEmpty()) {
            listState.animateScrollToItem(uiState.messages.size - 1)
        }
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(CyberBackground, CyberBackgroundEnd)
                )
            ),
        containerColor = Color.Transparent,
        contentWindowInsets = WindowInsets(0, 0, 0, 0)
    ) { paddingValues ->
        val statusBarPadding = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
        val navBarPadding = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(top = statusBarPadding, bottom = navBarPadding)
                .imePadding(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // 1. Sci-Fi HUD Header
            HudTopBar(
                telemetry = uiState.telemetry,
                coreState = uiState.coreState,
                hasApiKey = uiState.hasApiKey,
                isMuted = uiState.isMuted,
                onToggleMute = { viewModel.toggleMute() },
                onOpenSettings = { showSettings = true }
            )

            // 2. Quick Access Command Bar (Phone, Apps, Settings)
            QuickAccessBar(
                onPhoneClick = { viewModel.openDialerDirect() },
                onAppsClick = {
                    viewModel.refreshQuickApps()
                    showQuickApps = true
                },
                onSettingsClick = { showSettings = true }
            )

            // 3. Central Glowing Cyan AI Orb & Dynamic Audio Visualizer
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 2.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    JarvisGlowingCyanOrb(
                        state = uiState.coreState,
                        audioLevel = uiState.micAudioRms,
                        coreDiameter = 195.dp,
                        modifier = Modifier
                            .testTag("jarvis_glowing_orb")
                            .clickable {
                                if (uiState.coreState == JarvisCoreState.LISTENING) {
                                    viewModel.stopListening()
                                } else {
                                    checkAndStartListening()
                                }
                            }
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    HolographicAudioWaveform(
                        isSpeaking = uiState.coreState == JarvisCoreState.SPEAKING,
                        isListening = uiState.coreState == JarvisCoreState.LISTENING,
                        audioRms = uiState.micAudioRms,
                        modifier = Modifier
                            .fillMaxWidth(0.72f)
                            .height(20.dp)
                    )

                    // Spoken Status Banner & Live Speech Transcript
                    Box(
                        modifier = Modifier
                            .padding(horizontal = 14.dp, vertical = 2.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(CyberSurfaceCard)
                            .border(1.dp, BorderGlow, RoundedCornerShape(8.dp))
                            .padding(horizontal = 12.dp, vertical = 5.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (uiState.currentPartialSpeech.isNotBlank())
                                "बोल रहे हैं: \"${uiState.currentPartialSpeech}\""
                            else uiState.statusBannerText,
                            color = when (uiState.coreState) {
                                JarvisCoreState.LISTENING -> CyberGreen
                                JarvisCoreState.THINKING -> HoloAmber
                                else -> NeonCyan
                            },
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Medium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }

            // 4. Quick Action Hologram Voice Chips
            QuickActionChipsRow(
                onSelectQuery = { query ->
                    viewModel.submitPrompt(query, isVoiceInput = false)
                }
            )

            // 5. Conversation Transcript Stream
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp),
                contentPadding = PaddingValues(vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(uiState.messages, key = { it.id }) { message ->
                    MessageCard(
                        message = message,
                        onReplay = { viewModel.replayMessage(message) },
                        onCopy = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            val clip = ClipData.newPlainText("Rawan Message", message.text)
                            clipboard.setPrimaryClip(clip)
                            Toast.makeText(context, "कॉपी किया गया!", Toast.LENGTH_SHORT).show()
                        }
                    )
                }
            }

            // 6. Keyboard Text Input Drawer (Expandable)
            AnimatedVisibility(visible = showTextInput, enter = fadeIn(), exit = fadeOut()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = typedQuery,
                        onValueChange = { typedQuery = it },
                        placeholder = { Text("बोलें या टाइप करें (उदा. 'व्हाट्सएप खोलो')...", color = TextMuted, fontSize = 12.5.sp) },
                        singleLine = true,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("text_query_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeonCyan,
                            unfocusedBorderColor = BorderGlow,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        shape = RoundedCornerShape(12.dp)
                    )

                    Spacer(modifier = Modifier.width(6.dp))

                    IconButton(
                        onClick = {
                            if (typedQuery.isNotBlank()) {
                                viewModel.submitPrompt(typedQuery, isVoiceInput = false)
                                typedQuery = ""
                                showTextInput = false
                            }
                        },
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(NeonCyan)
                            .testTag("send_query_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Send,
                            contentDescription = "Send",
                            tint = CyberBackground,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            // 7. Interactive Deck: Glowing Cyan/Green Arc Mic, Continuous Mode & Controls
            InteractiveDeck(
                coreState = uiState.coreState,
                isContinuousMode = uiState.isContinuousMode,
                onMicClick = {
                    if (uiState.coreState == JarvisCoreState.LISTENING) {
                        viewModel.stopListening()
                    } else {
                        checkAndStartListening()
                    }
                },
                onStopClick = { viewModel.stopSpeaking() },
                onToggleKeyboard = { showTextInput = !showTextInput },
                onToggleContinuousMode = { viewModel.toggleContinuousMode() }
            )
        }
    }

    // Call Confirmation Modal (Guarantees calls are NEVER placed silently!)
    if (uiState.pendingCallTarget != null) {
        CallConfirmationModal(
            callTarget = uiState.pendingCallTarget!!,
            onConfirm = { viewModel.confirmPendingCall() },
            onCancel = { viewModel.cancelPendingCall() }
        )
    }

    // Quick Apps Matrix Sheet
    if (showQuickApps) {
        QuickAppsModal(
            apps = uiState.quickApps,
            onLaunchApp = { appItem ->
                showQuickApps = false
                viewModel.launchQuickApp(appItem)
            },
            onInstallApp = { pkg ->
                showQuickApps = false
                viewModel.openPlayStoreForApp(pkg)
            },
            onDismiss = { showQuickApps = false }
        )
    }

    // Uninstalled App Play Store Modal
    if (uiState.uninstalledAppPrompt != null) {
        val (appName, pkg) = uiState.uninstalledAppPrompt!!
        UninstalledAppModal(
            appName = appName,
            packageName = pkg,
            onDownload = { viewModel.openPlayStoreForApp(pkg) },
            onDismiss = { viewModel.dismissUninstalledAppPrompt() }
        )
    }

    // Settings & Permissions Dialog
    if (showSettings) {
        RawanSettingsDialog(
            currentApiKeyMasked = uiState.apiKeyMasked,
            hasApiKey = uiState.hasApiKey,
            voicePitch = uiState.voicePitch,
            voiceSpeed = uiState.voiceSpeed,
            isContinuousMode = uiState.isContinuousMode,
            isMuted = uiState.isMuted,
            isAccessibilityAuthorized = uiState.isAccessibilityAuthorized,
            onSaveApiKey = { viewModel.updateApiKey(it) },
            onSaveVoiceSettings = { pitch, speed -> viewModel.updateVoiceSettings(pitch, speed) },
            onToggleContinuousMode = { viewModel.toggleContinuousMode() },
            onToggleMute = { viewModel.toggleMute() },
            onOpenAccessibilitySettings = { viewModel.openAccessibilitySettings() },
            onTestVoice = { viewModel.testVoicePreview() },
            onClearChat = { viewModel.clearChat() },
            onDismiss = { showSettings = false }
        )
    }
}

@Composable
fun HudTopBar(
    telemetry: TelemetryData,
    coreState: JarvisCoreState,
    hasApiKey: Boolean,
    isMuted: Boolean,
    onToggleMute: () -> Unit,
    onOpenSettings: () -> Unit
) {
    Surface(
        color = CyberSurface,
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, BorderGlow)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 7.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "RAWAN",
                        color = NeonCyan,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 2.sp
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "v4.5 // J.A.R.V.I.S.",
                        color = ArcGlow,
                        fontSize = 9.5.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                // Telemetry metrics
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(top = 2.dp)
                ) {
                    Icon(
                        imageVector = if (telemetry.isCharging) Icons.Default.BatteryChargingFull else Icons.Default.BatteryFull,
                        contentDescription = null,
                        tint = if (telemetry.batteryPercent > 20) CyberGreen else CyberRed,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(2.dp))
                    Text(
                        text = "${telemetry.batteryPercent}%",
                        color = TextSecondary,
                        fontSize = 9.5.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(" • ", color = BorderGlow, fontSize = 9.5.sp)
                    Text(
                        text = telemetry.systemTime,
                        color = TextSecondary,
                        fontSize = 9.5.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(" • ", color = BorderGlow, fontSize = 9.5.sp)
                    Text(
                        text = if (hasApiKey) "FREE AI" else "OFFLINE",
                        color = if (hasApiKey) CyberGreen else HoloAmber,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                // Status Pill
                val (statusColor, statusLabel) = when (coreState) {
                    JarvisCoreState.LISTENING -> Pair(CyberGreen, "LISTENING")
                    JarvisCoreState.THINKING -> Pair(HoloAmber, "PROCESSING")
                    JarvisCoreState.SPEAKING -> Pair(NeonCyan, "SPEAKING")
                    JarvisCoreState.ERROR -> Pair(CyberRed, "ALERT")
                    JarvisCoreState.IDLE -> Pair(ArcGlow, "READY")
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(statusColor.copy(alpha = 0.15f))
                        .border(1.dp, statusColor.copy(alpha = 0.7f), RoundedCornerShape(6.dp))
                        .padding(horizontal = 7.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = statusLabel,
                        color = statusColor,
                        fontSize = 9.5.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Spacer(modifier = Modifier.width(4.dp))

                // Mute Toggle Icon
                IconButton(
                    onClick = onToggleMute,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = if (isMuted) Icons.AutoMirrored.Filled.VolumeMute else Icons.AutoMirrored.Filled.VolumeUp,
                        contentDescription = "Mute Toggle",
                        tint = if (isMuted) CyberRed else TextSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                }

                IconButton(
                    onClick = onOpenSettings,
                    modifier = Modifier
                        .size(32.dp)
                        .testTag("open_settings_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = "Settings",
                        tint = TextSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun QuickAccessBar(
    onPhoneClick: () -> Unit,
    onAppsClick: () -> Unit,
    onSettingsClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Quick Phone Button
        QuickButton(
            icon = Icons.Default.Phone,
            labelHindi = "फ़ोन",
            labelEnglish = "Phone",
            color = CyberGreen,
            onClick = onPhoneClick,
            modifier = Modifier.weight(1f)
        )

        // Quick Apps Button
        QuickButton(
            icon = Icons.Default.Apps,
            labelHindi = "ऐप्स",
            labelEnglish = "Apps",
            color = NeonCyan,
            onClick = onAppsClick,
            modifier = Modifier.weight(1f)
        )

        // Quick Settings Button
        QuickButton(
            icon = Icons.Default.Settings,
            labelHindi = "सेटिंग्स",
            labelEnglish = "Config",
            color = HoloAmber,
            onClick = onSettingsClick,
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
fun QuickButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    labelHindi: String,
    labelEnglish: String,
    color: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = CyberSurfaceVariant,
        shape = RoundedCornerShape(10.dp),
        modifier = modifier
            .border(1.dp, color.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "$labelHindi ($labelEnglish)",
                color = TextPrimary,
                fontSize = 11.5.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

@Composable
fun QuickActionChipsRow(
    onSelectQuery: (String) -> Unit
) {
    val quickQueries = listOf(
        "व्हाट्सएप खोलो",
        "यूट्यूब चलाओ",
        "पापा को कॉल लगाओ",
        "क्रोम ब्राउज़र खोलो",
        "होम स्क्रीन पर जाओ",
        "सिस्टम डायग्नोस्टिक्स रिपोर्ट",
        "एक मजेदार जोक सुनाओ",
        "चंद्रयान मिशन के बारे में बताओ",
        "ब्रह्मांड का रहस्य"
    )

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 12.dp, vertical = 3.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        quickQueries.forEach { query ->
            Surface(
                color = CyberSurfaceVariant,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .border(1.dp, BorderGlow, RoundedCornerShape(14.dp))
                    .clickable { onSelectQuery(query) }
            ) {
                Text(
                    text = query,
                    color = TextSecondary,
                    fontSize = 11.sp,
                    modifier = Modifier.padding(horizontal = 11.dp, vertical = 5.dp)
                )
            }
        }
    }
}

@Composable
fun MessageCard(
    message: RawanMessage,
    onReplay: () -> Unit,
    onCopy: () -> Unit
) {
    val isUser = message.sender == MessageSender.USER

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        Card(
            shape = RoundedCornerShape(
                topStart = 14.dp,
                topEnd = 14.dp,
                bottomStart = if (isUser) 14.dp else 2.dp,
                bottomEnd = if (isUser) 2.dp else 14.dp
            ),
            colors = CardDefaults.cardColors(
                containerColor = if (isUser) CyberSurfaceVariant else CyberSurfaceCard
            ),
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .border(
                    width = 1.dp,
                    color = if (isUser) BorderGlow else BorderCyan,
                    shape = RoundedCornerShape(14.dp)
                )
        ) {
            Column(modifier = Modifier.padding(11.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isUser) "YOU // USER" else "RAWAN // J.A.R.V.I.S.",
                        color = if (isUser) TextSecondary else NeonCyan,
                        fontSize = 9.5.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )

                    Row {
                        if (!isUser) {
                            IconButton(
                                onClick = onReplay,
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                                    contentDescription = "Replay audio",
                                    tint = ArcGlow,
                                    modifier = Modifier.size(15.dp)
                                )
                            }
                        }
                        IconButton(
                            onClick = onCopy,
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.ContentCopy,
                                contentDescription = "Copy message",
                                tint = TextMuted,
                                modifier = Modifier.size(13.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(3.dp))

                Text(
                    text = message.text,
                    color = TextPrimary,
                    fontSize = 13.sp,
                    lineHeight = 19.sp
                )
            }
        }
    }
}

@Composable
fun InteractiveDeck(
    coreState: JarvisCoreState,
    isContinuousMode: Boolean,
    onMicClick: () -> Unit,
    onStopClick: () -> Unit,
    onToggleKeyboard: () -> Unit,
    onToggleContinuousMode: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse_mic")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.14f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 750, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    Surface(
        color = CyberSurface,
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, BorderGlow)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp, vertical = 9.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Keyboard Input Button
            IconButton(
                onClick = onToggleKeyboard,
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(CyberSurfaceVariant)
                    .border(1.dp, BorderGlow, CircleShape)
                    .testTag("toggle_keyboard_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Keyboard,
                    contentDescription = "Type text",
                    tint = NeonCyan,
                    modifier = Modifier.size(20.dp)
                )
            }

            // Big Glowing Center Audio Mic Button
            Box(
                modifier = Modifier
                    .size(66.dp)
                    .scale(if (coreState == JarvisCoreState.LISTENING) pulseScale else 1f),
                contentAlignment = Alignment.Center
            ) {
                // Outer Pulse Ring when listening
                if (coreState == JarvisCoreState.LISTENING) {
                    Box(
                        modifier = Modifier
                            .size(66.dp)
                            .clip(CircleShape)
                            .background(CyberGreen.copy(alpha = 0.28f))
                    )
                }

                Box(
                    modifier = Modifier
                        .size(54.dp)
                        .clip(CircleShape)
                        .background(
                            when (coreState) {
                                JarvisCoreState.LISTENING -> CyberGreen
                                JarvisCoreState.SPEAKING -> ArcGlow
                                else -> NeonCyan
                            }
                        )
                        .clickable { onMicClick() }
                        .testTag("main_mic_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (coreState == JarvisCoreState.LISTENING) Icons.Default.MicOff else Icons.Default.Mic,
                        contentDescription = "Microphone",
                        tint = CyberBackground,
                        modifier = Modifier.size(26.dp)
                    )
                }
            }

            // Stop Speaking / Continuous Mode Controls
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (coreState == JarvisCoreState.SPEAKING) {
                    IconButton(
                        onClick = onStopClick,
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(CyberRed.copy(alpha = 0.2f))
                            .border(1.dp, CyberRed, CircleShape)
                            .testTag("stop_speaking_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Stop,
                            contentDescription = "Stop speaking",
                            tint = CyberRed,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                } else {
                    // Continuous mode quick badge
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isContinuousMode) CyberGreen.copy(alpha = 0.15f) else CyberSurfaceVariant)
                            .border(1.dp, if (isContinuousMode) CyberGreen else BorderGlow, RoundedCornerShape(12.dp))
                            .clickable { onToggleContinuousMode() }
                            .padding(horizontal = 9.dp, vertical = 7.dp)
                            .testTag("toggle_continuous_chip")
                    ) {
                        Text(
                            text = if (isContinuousMode) "AUTO • ON" else "AUTO • OFF",
                            color = if (isContinuousMode) CyberGreen else TextMuted,
                            fontSize = 9.5.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }
}
