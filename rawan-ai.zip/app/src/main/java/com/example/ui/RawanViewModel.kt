package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.GeminiApiClient
import com.example.data.MessageSender
import com.example.data.RawanKnowledgeBase
import com.example.data.RawanMessage
import com.example.data.SettingsRepository
import com.example.data.SystemDiagnosticsHelper
import com.example.data.TelemetryData
import com.example.phone.AppControlManager
import com.example.phone.AppLaunchResult
import com.example.phone.CallTarget
import com.example.phone.PhoneCallManager
import com.example.phone.QuickAppItem
import com.example.service.RawanAccessibilityService
import com.example.ui.components.JarvisCoreState
import com.example.voice.AccessibilityActionType
import com.example.voice.ParsedVoiceAction
import com.example.voice.RawanVoiceManager
import com.example.voice.SystemControlType
import com.example.voice.VoiceCommandParser
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class RawanUiState(
    val coreState: JarvisCoreState = JarvisCoreState.IDLE,
    val micAudioRms: Float = 0f,
    val currentPartialSpeech: String = "",
    val messages: List<RawanMessage> = emptyList(),
    val telemetry: TelemetryData = TelemetryData(),
    val isContinuousMode: Boolean = false,
    val isMuted: Boolean = false,
    val hasApiKey: Boolean = false,
    val apiKeyMasked: String = "",
    val voicePitch: Float = 1.15f,
    val voiceSpeed: Float = 1.0f,
    val statusBannerText: String = "नमस्ते बॉस! मैं रावन हूँ, आपकी एआई सहायक।",
    val pendingCallTarget: CallTarget? = null,
    val uninstalledAppPrompt: Pair<String, String>? = null, // appName, packageName
    val isAccessibilityAuthorized: Boolean = false,
    val quickApps: List<QuickAppItem> = emptyList()
)

class RawanViewModel(application: Application) : AndroidViewModel(application) {

    private val settingsRepo = SettingsRepository(application)
    private val diagnosticsHelper = SystemDiagnosticsHelper(application)
    private val knowledgeBase = RawanKnowledgeBase(diagnosticsHelper)
    private val geminiApiClient = GeminiApiClient(settingsRepo, knowledgeBase)

    private val appControlManager = AppControlManager(application)
    private val phoneCallManager = PhoneCallManager(application)
    private val voiceCommandParser = VoiceCommandParser(appControlManager, phoneCallManager)

    private val _uiState = MutableStateFlow(
        RawanUiState(
            telemetry = diagnosticsHelper.getTelemetry(),
            isContinuousMode = settingsRepo.isContinuousMode(),
            hasApiKey = settingsRepo.getEffectiveApiKey().isNotBlank(),
            apiKeyMasked = maskApiKey(settingsRepo.getEffectiveApiKey()),
            voicePitch = settingsRepo.getVoicePitch(),
            voiceSpeed = settingsRepo.getVoiceSpeed(),
            isAccessibilityAuthorized = RawanAccessibilityService.isServiceAuthorized(application),
            quickApps = appControlManager.getQuickAppsList()
        )
    )
    val uiState: StateFlow<RawanUiState> = _uiState.asStateFlow()

    private var voiceManager: RawanVoiceManager? = null
    private var telemetryJob: Job? = null

    init {
        initVoiceManager()
        startTelemetryLoop()

        // Welcome greeting in conversation
        val welcomeMessage = RawanMessage(
            sender = MessageSender.RAWAN,
            text = "नमस्ते बॉस! मैं रावन (RAWAN) हूँ — आपकी जार्विस स्टाइल एआई सहायक। आप बोल सकते हैं 'व्हाट्सएप खोलो', 'पापा को कॉल लगाओ', 'यूट्यूब चलाओ', या कोई भी प्रश्न पूछें!",
            isVoice = false
        )
        _uiState.update { it.copy(messages = listOf(welcomeMessage)) }
    }

    private fun initVoiceManager() {
        voiceManager = RawanVoiceManager(
            context = getApplication(),
            settingsRepository = settingsRepo,
            onSpeechRecognized = { recognizedText ->
                onUserSpeechReceived(recognizedText)
            },
            onPartialSpeech = { partialText ->
                _uiState.update { it.copy(currentPartialSpeech = partialText) }
            },
            onRmsChanged = { rmsNorm ->
                _uiState.update { it.copy(micAudioRms = rmsNorm) }
            },
            onListeningStateChanged = { isListening ->
                _uiState.update {
                    it.copy(
                        coreState = if (isListening) JarvisCoreState.LISTENING else JarvisCoreState.IDLE,
                        statusBannerText = if (isListening) "सुन रही हूँ... बोलिए बॉस!" else "प्रतीक्षा में..."
                    )
                }
            },
            onSpeakingStateChanged = { isSpeaking ->
                _uiState.update {
                    it.copy(
                        coreState = if (isSpeaking) JarvisCoreState.SPEAKING else JarvisCoreState.IDLE,
                        statusBannerText = if (isSpeaking) "रावन बोल रही है..." else "सक्रिय"
                    )
                }
                // Continuous listening loop ONLY when user explicitly enabled it
                if (!isSpeaking && _uiState.value.isContinuousMode && _uiState.value.pendingCallTarget == null) {
                    viewModelScope.launch {
                        delay(500)
                        startListening()
                    }
                }
            },
            onError = { errMsg ->
                _uiState.update {
                    it.copy(
                        coreState = JarvisCoreState.IDLE,
                        statusBannerText = errMsg
                    )
                }
            }
        )
    }

    private fun startTelemetryLoop() {
        telemetryJob = viewModelScope.launch {
            while (true) {
                val tel = diagnosticsHelper.getTelemetry()
                val isAccessAuth = RawanAccessibilityService.isServiceAuthorized(getApplication())
                _uiState.update {
                    it.copy(
                        telemetry = tel,
                        isAccessibilityAuthorized = isAccessAuth
                    )
                }
                delay(4000)
            }
        }
    }

    fun startListening() {
        _uiState.update { it.copy(currentPartialSpeech = "", micAudioRms = 0f) }
        voiceManager?.startListening()
    }

    fun stopListening() {
        voiceManager?.stopListening()
    }

    fun stopSpeaking() {
        voiceManager?.stopSpeaking()
        _uiState.update {
            it.copy(
                coreState = JarvisCoreState.IDLE,
                statusBannerText = "आवाज़ रोकी गई।"
            )
        }
    }

    fun toggleMute() {
        val newMute = !_uiState.value.isMuted
        voiceManager?.isMuted = newMute
        if (newMute) {
            voiceManager?.stopSpeaking()
        }
        _uiState.update {
            it.copy(
                isMuted = newMute,
                statusBannerText = if (newMute) "म्यूट सक्रिय (Silent Mode)" else "आवाज़ चालू (Voice Active)"
            )
        }
    }

    private fun onUserSpeechReceived(speechText: String) {
        _uiState.update { it.copy(currentPartialSpeech = "") }
        submitPrompt(speechText, isVoiceInput = true)
    }

    fun submitPrompt(promptText: String, isVoiceInput: Boolean = false) {
        val trimmed = promptText.trim()
        if (trimmed.isBlank()) return

        stopSpeaking()

        // 1. Check if user is confirming or cancelling a pending call
        if (_uiState.value.pendingCallTarget != null) {
            val lower = trimmed.lowercase()
            if (lower.contains("haan") || lower.contains("हाँ") || lower.contains("yes") ||
                lower.contains("call lagao") || lower.contains("कॉल लगाओ") || lower.contains("dial") ||
                lower.contains("ok") || lower.contains("karo") || lower.contains("करो")
            ) {
                confirmPendingCall()
                return
            } else if (lower.contains("nahi") || lower.contains("नहीं") || lower.contains("cancel") ||
                lower.contains("रद्द") || lower.contains("mat karo") || lower.contains("मत करो")
            ) {
                cancelPendingCall()
                return
            }
        }

        val userMsg = RawanMessage(
            sender = MessageSender.USER,
            text = trimmed,
            isVoice = isVoiceInput
        )
        _uiState.update { it.copy(messages = it.messages + userMsg) }

        // 2. Parse voice action through VoiceCommandParser
        val parsedAction = voiceCommandParser.parse(trimmed)
        when (parsedAction) {
            is ParsedVoiceAction.CallConfirmationRequired -> {
                handleCallAction(parsedAction.target)
            }
            is ParsedVoiceAction.LaunchApp -> {
                handleAppLaunchAction(parsedAction.appTarget)
            }
            is ParsedVoiceAction.AccessibilityNav -> {
                handleAccessibilityAction(parsedAction.actionType)
            }
            is ParsedVoiceAction.SystemControl -> {
                handleSystemControlAction(parsedAction.controlType)
            }
            is ParsedVoiceAction.ConversationalQuery -> {
                handleConversationalQuery(trimmed)
            }
        }
    }

    private fun handleCallAction(target: CallTarget) {
        _uiState.update {
            it.copy(
                pendingCallTarget = target,
                coreState = JarvisCoreState.SPEAKING
            )
        }

        val questionText = if (target.phoneNumber.isNotBlank()) {
            "क्या आप ${target.displayName} (${target.phoneNumber}) पर कॉल लगाना चाहते हैं? कृपया पुष्टि करें।"
        } else {
            "क्या आप ${target.displayName} के लिए डायलर खोलना चाहते हैं? कृपया पुष्टि करें।"
        }

        val rawanMsg = RawanMessage(
            sender = MessageSender.RAWAN,
            text = questionText,
            isVoice = true
        )
        _uiState.update {
            it.copy(
                messages = it.messages + rawanMsg,
                statusBannerText = "कॉल की पुष्टि की प्रतीक्षा..."
            )
        }
        voiceManager?.speak(questionText)
    }

    fun confirmPendingCall() {
        val target = _uiState.value.pendingCallTarget ?: return
        _uiState.update {
            it.copy(
                pendingCallTarget = null,
                coreState = JarvisCoreState.IDLE,
                statusBannerText = "डायलर खोला जा रहा है..."
            )
        }

        val confirmText = "जी बॉस, ${target.displayName} के लिए डायलर खोला जा रहा है।"
        val rawanMsg = RawanMessage(
            sender = MessageSender.RAWAN,
            text = confirmText,
            isVoice = true
        )
        _uiState.update { it.copy(messages = it.messages + rawanMsg) }
        voiceManager?.speak(confirmText)

        // NEVER place calls silently; opens system dialer with number pre-filled for user confirmation
        phoneCallManager.openDialer(target.phoneNumber)
    }

    fun cancelPendingCall() {
        _uiState.update {
            it.copy(
                pendingCallTarget = null,
                coreState = JarvisCoreState.IDLE,
                statusBannerText = "कॉल रद्द कर दी गई।"
            )
        }
        val cancelText = "कॉल रद्द कर दी गई है, बॉस।"
        val rawanMsg = RawanMessage(
            sender = MessageSender.RAWAN,
            text = cancelText,
            isVoice = true
        )
        _uiState.update { it.copy(messages = it.messages + rawanMsg) }
        voiceManager?.speak(cancelText)
    }

    private fun handleAppLaunchAction(appTarget: AppControlManager.AppTarget) {
        val result = appControlManager.launchApp(appTarget)
        when (result) {
            is AppLaunchResult.Success -> {
                val text = "जी बॉस, ${result.appName} खोला जा रहा है।"
                val rawanMsg = RawanMessage(sender = MessageSender.RAWAN, text = text, isVoice = true)
                _uiState.update {
                    it.copy(
                        messages = it.messages + rawanMsg,
                        coreState = JarvisCoreState.SPEAKING,
                        statusBannerText = "${result.appName} खोला जा रहा है..."
                    )
                }
                voiceManager?.speak(text)
            }
            is AppLaunchResult.NotInstalled -> {
                val text = "बॉस, ${result.appName} आपके फ़ोन में इंस्टॉल नहीं है। क्या आप इसे Google Play Store से डाउनलोड करना चाहते हैं?"
                val rawanMsg = RawanMessage(sender = MessageSender.RAWAN, text = text, isVoice = true)
                _uiState.update {
                    it.copy(
                        messages = it.messages + rawanMsg,
                        uninstalledAppPrompt = Pair(result.appName, result.packageName),
                        coreState = JarvisCoreState.SPEAKING,
                        statusBannerText = "${result.appName} इंस्टॉल नहीं है।"
                    )
                }
                voiceManager?.speak(text)
            }
            is AppLaunchResult.Unrecognized -> {
                handleConversationalQuery(appTarget.displayNameHindi)
            }
        }
    }

    fun launchQuickApp(item: QuickAppItem) {
        val target = appControlManager.findAppByVoiceCommand(item.id) ?: return
        handleAppLaunchAction(target)
    }

    fun openPlayStoreForApp(packageName: String) {
        _uiState.update { it.copy(uninstalledAppPrompt = null) }
        appControlManager.openPlayStore(packageName)
    }

    fun dismissUninstalledAppPrompt() {
        _uiState.update { it.copy(uninstalledAppPrompt = null) }
    }

    private fun handleAccessibilityAction(actionType: AccessibilityActionType) {
        val isAuthorized = RawanAccessibilityService.isServiceAuthorized(getApplication())
        if (!isAuthorized) {
            val text = "बॉस, स्क्रीन नेविगेशन के लिए एक्सेसिबिलिटी सर्विस की अनुमति आवश्यक है। सेटिंग्स में जाकर रावन को अनुमति दें।"
            val rawanMsg = RawanMessage(sender = MessageSender.RAWAN, text = text, isVoice = true)
            _uiState.update {
                it.copy(
                    messages = it.messages + rawanMsg,
                    coreState = JarvisCoreState.SPEAKING,
                    statusBannerText = "एक्सेसिबिलिटी सर्विस की अनुमति आवश्यक है।"
                )
            }
            voiceManager?.speak(text)
            return
        }

        val success = when (actionType) {
            AccessibilityActionType.HOME -> RawanAccessibilityService.performHome()
            AccessibilityActionType.BACK -> RawanAccessibilityService.performBack()
            AccessibilityActionType.RECENTS -> RawanAccessibilityService.performRecents()
            AccessibilityActionType.NOTIFICATIONS -> RawanAccessibilityService.performNotifications()
            AccessibilityActionType.QUICK_SETTINGS -> RawanAccessibilityService.performQuickSettings()
            AccessibilityActionType.SCREENSHOT -> RawanAccessibilityService.performScreenshot()
        }

        val feedback = when (actionType) {
            AccessibilityActionType.HOME -> "होम स्क्रीन पर जा रहे हैं।"
            AccessibilityActionType.BACK -> "पीछे जा रहे हैं।"
            AccessibilityActionType.RECENTS -> "रीसेंट ऐप्स खोले गए।"
            AccessibilityActionType.NOTIFICATIONS -> "नोटिफिकेशन्स दिखाए गए।"
            AccessibilityActionType.QUICK_SETTINGS -> "क्विक सेटिंग्स खुली।"
            AccessibilityActionType.SCREENSHOT -> if (success) "स्क्रीनशॉट ले लिया गया।" else "स्क्रीनशॉट समर्थित नहीं है।"
        }

        val rawanMsg = RawanMessage(sender = MessageSender.RAWAN, text = feedback, isVoice = true)
        _uiState.update {
            it.copy(
                messages = it.messages + rawanMsg,
                statusBannerText = feedback
            )
        }
        voiceManager?.speak(feedback)
    }

    fun openAccessibilitySettings() {
        RawanAccessibilityService.openSettings(getApplication())
    }

    private fun handleSystemControlAction(controlType: SystemControlType) {
        when (controlType) {
            SystemControlType.MUTE_VOICE -> {
                toggleMute()
            }
            SystemControlType.UNMUTE_VOICE -> {
                if (_uiState.value.isMuted) toggleMute()
            }
            SystemControlType.STOP_SPEAKING -> {
                stopSpeaking()
            }
            SystemControlType.OPEN_ACCESSIBILITY_SETTINGS -> {
                openAccessibilitySettings()
            }
            SystemControlType.BATTERY_CHECK -> {
                val report = diagnosticsHelper.getSpokenDiagnosticReport()
                val rawanMsg = RawanMessage(sender = MessageSender.RAWAN, text = report, isVoice = true)
                _uiState.update { it.copy(messages = it.messages + rawanMsg, coreState = JarvisCoreState.SPEAKING) }
                voiceManager?.speak(report)
            }
            SystemControlType.TIME_CHECK -> {
                val report = knowledgeBase.findQuickResponse("time") ?: "समय देखा जा रहा है..."
                val rawanMsg = RawanMessage(sender = MessageSender.RAWAN, text = report, isVoice = true)
                _uiState.update { it.copy(messages = it.messages + rawanMsg, coreState = JarvisCoreState.SPEAKING) }
                voiceManager?.speak(report)
            }
        }
    }

    private fun handleConversationalQuery(query: String) {
        _uiState.update {
            it.copy(
                coreState = JarvisCoreState.THINKING,
                statusBannerText = "विश्लेषण कर रही हूँ..."
            )
        }

        viewModelScope.launch {
            val result = geminiApiClient.generateResponse(query, _uiState.value.messages)
            val answer = result.getOrElse {
                "क्षमा करें, मुझे इस समय जानकारी संसाधित करने में समस्या आ रही है। कृपया पुनः प्रयास करें।"
            }

            val rawanMsg = RawanMessage(
                sender = MessageSender.RAWAN,
                text = answer,
                isVoice = true
            )

            _uiState.update {
                it.copy(
                    messages = it.messages + rawanMsg,
                    coreState = JarvisCoreState.SPEAKING,
                    statusBannerText = "रावन बोल रही है..."
                )
            }

            // Audio output in female Hindi voice!
            voiceManager?.speak(answer)
        }
    }

    fun replayMessage(message: RawanMessage) {
        stopSpeaking()
        _uiState.update {
            it.copy(
                coreState = JarvisCoreState.SPEAKING,
                statusBannerText = "पुनः बोल रही हूँ..."
            )
        }
        voiceManager?.speak(message.text)
    }

    fun openDialerDirect(phoneNumber: String = "") {
        phoneCallManager.openDialer(phoneNumber)
    }

    fun updateApiKey(apiKey: String) {
        settingsRepo.setCustomApiKey(apiKey)
        val effKey = settingsRepo.getEffectiveApiKey()
        _uiState.update {
            it.copy(
                hasApiKey = effKey.isNotBlank(),
                apiKeyMasked = maskApiKey(effKey),
                statusBannerText = if (effKey.isNotBlank()) "API Key सफलतापूर्वक अपडेट की गई!" else "API Key हटा दी गई।"
            )
        }
    }

    fun updateVoiceSettings(pitch: Float, speed: Float) {
        settingsRepo.setVoicePitch(pitch)
        settingsRepo.setVoiceSpeed(speed)
        voiceManager?.applyVoiceSettings()
        _uiState.update {
            it.copy(voicePitch = pitch, voiceSpeed = speed)
        }
    }

    fun testVoicePreview() {
        stopSpeaking()
        voiceManager?.applyVoiceSettings()
        voiceManager?.speak("नमस्ते! मैं रावन हूँ। यह मेरी हिंदी महिला आवाज़ का परीक्षण है। क्या यह मधुर और स्पष्ट है?")
    }

    fun toggleContinuousMode() {
        val newMode = !_uiState.value.isContinuousMode
        settingsRepo.setContinuousMode(newMode)
        _uiState.update { it.copy(isContinuousMode = newMode) }
    }

    fun clearChat() {
        stopSpeaking()
        val resetMsg = RawanMessage(
            sender = MessageSender.RAWAN,
            text = "चैट इतिहास रीसेट कर दिया गया है। नया संवाद शुरू करें!",
            isVoice = false
        )
        _uiState.update { it.copy(messages = listOf(resetMsg)) }
    }

    fun refreshQuickApps() {
        _uiState.update { it.copy(quickApps = appControlManager.getQuickAppsList()) }
    }

    private fun maskApiKey(key: String): String {
        if (key.length <= 8) return if (key.isNotEmpty()) "••••••••" else ""
        return "${key.take(4)}••••••••${key.takeLast(4)}"
    }

    override fun onCleared() {
        super.onCleared()
        telemetryJob?.cancel()
        voiceManager?.destroy()
    }
}
