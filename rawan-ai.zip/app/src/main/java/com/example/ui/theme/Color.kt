package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Futuristic JARVIS Cyber Dark Palette
val CyberBackground = Color(0xFF060911)
val CyberBackgroundEnd = Color(0xFF0B1220)
val CyberSurface = Color(0xFF0F1829)
val CyberSurfaceVariant = Color(0xFF16233B)
val CyberSurfaceCard = Color(0xCC111C30)

// Holographic Glowing Accents
val NeonCyan = Color(0xFF00F0FF)
val ElectricBlue = Color(0xFF0077FE)
val HoloAmber = Color(0xFFFFB703)
val ArcGlow = Color(0xFF38E5FF)
val CyberGreen = Color(0xFF00FFA3)
val CyberRed = Color(0xFFFF3366)
val CyberPurple = Color(0xFF9D4EDD)

// Text & HUD Lines
val TextPrimary = Color(0xFFE8F1FC)
val TextSecondary = Color(0xFF8CA3C7)
val TextMuted = Color(0xFF556E8F)
val BorderGlow = Color(0xFF1E3A5F)
val BorderCyan = Color(0x6600F0FF)
