package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.theme.ArcGlow
import com.example.ui.theme.BorderGlow
import com.example.ui.theme.CyberBackground
import com.example.ui.theme.CyberGreen
import com.example.ui.theme.CyberRed
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.HoloAmber
import com.example.ui.theme.NeonCyan
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

enum class JarvisCoreState {
    IDLE,
    LISTENING,
    THINKING,
    SPEAKING,
    ERROR
}

@Composable
fun JarvisGlowingCyanOrb(
    state: JarvisCoreState,
    audioLevel: Float, // 0f .. 1f
    modifier: Modifier = Modifier,
    coreDiameter: Dp = 210.dp
) {
    val infiniteTransition = rememberInfiniteTransition(label = "jarvis_orb_anim")

    // Slow clockwise rotation
    val rotationClockwise by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 12000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation_cw"
    )

    // Fast counter-clockwise rotation (speeds up when thinking)
    val counterDuration = if (state == JarvisCoreState.THINKING) 2500 else 8000
    val rotationCounter by infiniteTransition.animateFloat(
        initialValue = 360f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = counterDuration, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation_ccw"
    )

    // Pulsing core breathing
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.94f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = when (state) {
                    JarvisCoreState.SPEAKING -> 400
                    JarvisCoreState.LISTENING -> 600
                    JarvisCoreState.THINKING -> 500
                    else -> 1800
                },
                easing = FastOutSlowInEasing
            ),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    // Orb Aura expansion
    val auraScale by infiniteTransition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.18f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "aura_scale"
    )

    // Dynamic wave phase for speaking/listening
    val wavePhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 2f * PI.toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "wave_phase"
    )

    val coreColor = when (state) {
        JarvisCoreState.LISTENING -> CyberGreen
        JarvisCoreState.THINKING -> HoloAmber
        JarvisCoreState.SPEAKING -> NeonCyan
        JarvisCoreState.ERROR -> CyberRed
        JarvisCoreState.IDLE -> NeonCyan
    }

    Box(
        modifier = modifier.size(coreDiameter),
        contentAlignment = Alignment.Center
    ) {
        // Holographic Glowing Cyan AI Canvas
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val maxRadius = size.width / 2f - 6.dp.toPx()

            // 1. Deep Atmospheric Glowing Cyan AI Orb Halo (Radial Aura)
            val auraRadius = maxRadius * auraScale
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        coreColor.copy(alpha = 0.45f),
                        ElectricBlue.copy(alpha = 0.25f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = auraRadius
                ),
                radius = auraRadius,
                center = center
            )

            // 2. Outer Rotating Sci-Fi Ring with Compass Ticks
            rotate(rotationClockwise, center) {
                val tickRadius = maxRadius
                val tickCount = 48
                for (i in 0 until tickCount) {
                    val angle = (i * (360f / tickCount)) * (PI.toFloat() / 180f)
                    val isMajor = i % 4 == 0
                    val length = if (isMajor) 10.dp.toPx() else 4.dp.toPx()
                    val color = if (isMajor) coreColor.copy(alpha = 0.9f) else BorderGlow.copy(alpha = 0.5f)
                    val strokeW = if (isMajor) 2.2.dp.toPx() else 1.dp.toPx()

                    val startX = center.x + (tickRadius - length) * cos(angle)
                    val startY = center.y + (tickRadius - length) * sin(angle)
                    val endX = center.x + tickRadius * cos(angle)
                    val endY = center.y + tickRadius * sin(angle)

                    drawLine(
                        color = color,
                        start = Offset(startX, startY),
                        end = Offset(endX, endY),
                        strokeWidth = strokeW,
                        cap = StrokeCap.Round
                    )
                }
            }

            // 3. Middle Counter-Rotating Dashed Quantum Gyro Ring
            rotate(rotationCounter, center) {
                val middleRadius = maxRadius * 0.85f
                val dashEffect = PathEffect.dashPathEffect(floatArrayOf(28f, 16f, 10f, 16f), 0f)
                drawCircle(
                    color = coreColor.copy(alpha = 0.70f),
                    radius = middleRadius,
                    center = center,
                    style = Stroke(width = 2.5f, pathEffect = dashEffect)
                )

                // 4 Cardinal Hologram Brackets
                for (angle in listOf(0f, 90f, 180f, 270f)) {
                    drawArc(
                        color = if (state == JarvisCoreState.THINKING) HoloAmber else ArcGlow,
                        startAngle = angle - 16f,
                        sweepAngle = 32f,
                        useCenter = false,
                        topLeft = Offset(center.x - middleRadius, center.y - middleRadius),
                        size = Size(middleRadius * 2, middleRadius * 2),
                        style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round)
                    )
                }

                // Orbiting Energy Nodes
                for (orbitAngle in listOf(45f, 135f, 225f, 315f)) {
                    val rad = orbitAngle * (PI.toFloat() / 180f)
                    val nodeX = center.x + middleRadius * cos(rad)
                    val nodeY = center.y + middleRadius * sin(rad)
                    drawCircle(
                        color = coreColor,
                        radius = 3.dp.toPx(),
                        center = Offset(nodeX, nodeY)
                    )
                }
            }

            // 4. Audio Frequency Radial Spectrum (Reacts to mic audio & voice harmonics)
            val audioRadius = maxRadius * 0.71f
            val bars = 36
            val effectiveAmplitude = when (state) {
                JarvisCoreState.LISTENING -> (audioLevel * 1.6f + 0.15f).coerceIn(0.1f, 1f)
                JarvisCoreState.SPEAKING -> (0.35f + 0.50f * sin(wavePhase)).coerceIn(0.2f, 0.95f)
                JarvisCoreState.THINKING -> 0.28f
                else -> 0.08f
            }

            for (i in 0 until bars) {
                val angle = (i * (360f / bars)) * (PI.toFloat() / 180f)
                val waveOffset = sin(i * 0.65f + wavePhase) * effectiveAmplitude
                val barHeight = (4.dp.toPx() + (waveOffset * 20.dp.toPx())).coerceAtLeast(2.dp.toPx())

                val startX = center.x + audioRadius * cos(angle)
                val startY = center.y + audioRadius * sin(angle)
                val endX = center.x + (audioRadius + barHeight) * cos(angle)
                val endY = center.y + (audioRadius + barHeight) * sin(angle)

                drawLine(
                    color = coreColor.copy(alpha = 0.85f),
                    start = Offset(startX, startY),
                    end = Offset(endX, endY),
                    strokeWidth = 2.2.dp.toPx(),
                    cap = StrokeCap.Round
                )
            }

            // 5. Pulsing Glowing Cyan AI Orb Sphere
            val innerRadius = maxRadius * 0.55f * pulseScale
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        coreColor.copy(alpha = 0.60f),
                        ElectricBlue.copy(alpha = 0.35f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = innerRadius * 1.45f
                ),
                radius = innerRadius * 1.35f,
                center = center
            )

            drawCircle(
                color = coreColor,
                radius = innerRadius,
                center = center,
                style = Stroke(width = 2.5.dp.toPx())
            )
        }

        // Center Avatar / AI Holographic Orb Core
        Box(
            modifier = Modifier
                .size(coreDiameter * 0.44f)
                .clip(CircleShape)
                .background(CyberBackground)
                .border(2.dp, coreColor, CircleShape)
                .padding(4.dp),
            contentAlignment = Alignment.Center
        ) {
            Image(
                painter = painterResource(id = R.drawable.ic_rawan_core),
                contentDescription = "Rawan AI Orb Core",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxSize()
                    .clip(CircleShape)
            )
        }
    }
}

@Composable
fun HolographicAudioWaveform(
    isSpeaking: Boolean,
    isListening: Boolean,
    audioRms: Float,
    modifier: Modifier = Modifier,
    barCount: Int = 28
) {
    val infiniteTransition = rememberInfiniteTransition(label = "audio_bars")
    val phase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 2 * PI.toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 850, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "phase"
    )

    Canvas(modifier = modifier) {
        val totalWidth = size.width
        val barWidth = (totalWidth / (barCount * 1.6f)).coerceAtLeast(3f)
        val spacing = barWidth * 0.6f
        val startX = (totalWidth - (barCount * (barWidth + spacing))) / 2f
        val centerY = size.height / 2f

        for (i in 0 until barCount) {
            val progress = i.toFloat() / barCount.toFloat()
            val heightMultiplier = when {
                isListening -> (audioRms * 1.7f + 0.18f * sin(i * 0.85f + phase)).coerceIn(0.1f, 1f)
                isSpeaking -> (0.35f + 0.65f * sin(progress * 4f * PI.toFloat() + phase).let { kotlin.math.abs(it) }).coerceIn(0.15f, 1f)
                else -> (0.1f + 0.08f * sin(i * 0.5f + phase)).coerceIn(0.05f, 0.3f)
            }

            val barHeight = (size.height * heightMultiplier * 0.90f).coerceAtLeast(4.dp.toPx())
            val x = startX + i * (barWidth + spacing)
            val top = centerY - barHeight / 2f

            val color = when {
                isListening -> CyberGreen
                isSpeaking -> NeonCyan
                else -> ArcGlow.copy(alpha = 0.45f)
            }

            drawRoundRect(
                color = color,
                topLeft = Offset(x, top),
                size = Size(barWidth, barHeight),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(2.dp.toPx())
            )
        }
    }
}
