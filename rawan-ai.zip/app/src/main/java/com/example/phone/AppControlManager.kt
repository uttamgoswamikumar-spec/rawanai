package com.example.phone

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.MediaStore
import android.provider.Settings

sealed class AppLaunchResult {
    data class Success(val appName: String, val packageName: String) : AppLaunchResult()
    data class NotInstalled(val appName: String, val packageName: String) : AppLaunchResult()
    data object Unrecognized : AppLaunchResult()
}

data class QuickAppItem(
    val id: String,
    val nameHindi: String,
    val nameEnglish: String,
    val packageName: String,
    val isInstalled: Boolean
)

class AppControlManager(private val context: Context) {

    data class AppTarget(
        val id: String,
        val displayNameHindi: String,
        val displayNameEnglish: String,
        val primaryPackage: String,
        val alternatePackages: List<String> = emptyList(),
        val intentProvider: (() -> Intent)? = null,
        val keywords: List<String>
    )

    private val supportedApps = listOf(
        AppTarget(
            id = "whatsapp",
            displayNameHindi = "व्हाट्सएप",
            displayNameEnglish = "WhatsApp",
            primaryPackage = "com.whatsapp",
            alternatePackages = listOf("com.whatsapp.w4b"),
            keywords = listOf("whatsapp", "व्हाट्सएप", "व्हाट्सऐप", "वाट्सएप", "वाटसप")
        ),
        AppTarget(
            id = "youtube",
            displayNameHindi = "यूट्यूब",
            displayNameEnglish = "YouTube",
            primaryPackage = "com.google.android.youtube",
            intentProvider = {
                Intent(Intent.ACTION_VIEW, Uri.parse("vnd.youtube:")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            },
            keywords = listOf("youtube", "यूट्यूब", "युटुब", "विडियो", "वीडियो")
        ),
        AppTarget(
            id = "chrome",
            displayNameHindi = "क्रोम ब्राउज़र",
            displayNameEnglish = "Chrome",
            primaryPackage = "com.android.chrome",
            intentProvider = {
                Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            },
            keywords = listOf("chrome", "क्रोम", "ब्राउज़र", "browser", "इंटरनेट")
        ),
        AppTarget(
            id = "phone",
            displayNameHindi = "फ़ोन / डायलर",
            displayNameEnglish = "Phone",
            primaryPackage = "com.google.android.dialer",
            intentProvider = {
                Intent(Intent.ACTION_DIAL).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            },
            keywords = listOf("phone", "फ़ोन", "फोन", "dialer", "डायलर", "कॉल")
        ),
        AppTarget(
            id = "messages",
            displayNameHindi = "मैसेज / संदेश",
            displayNameEnglish = "Messages",
            primaryPackage = "com.google.android.apps.messaging",
            intentProvider = {
                Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            },
            keywords = listOf("messages", "message", "मैसेज", "sms", "एसएमएस", "संदेश")
        ),
        AppTarget(
            id = "settings",
            displayNameHindi = "फ़ोन सेटिंग्स",
            displayNameEnglish = "Settings",
            primaryPackage = "com.android.settings",
            intentProvider = {
                Intent(Settings.ACTION_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            },
            keywords = listOf("settings", "setting", "सेटिंग्स", "सेटिंग")
        ),
        AppTarget(
            id = "camera",
            displayNameHindi = "कैमरा",
            displayNameEnglish = "Camera",
            primaryPackage = "com.google.android.GoogleCamera",
            intentProvider = {
                Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            },
            keywords = listOf("camera", "कैमरा", "फोटो", "photo")
        ),
        AppTarget(
            id = "maps",
            displayNameHindi = "गूगल मैप्स",
            displayNameEnglish = "Google Maps",
            primaryPackage = "com.google.android.apps.maps",
            intentProvider = {
                Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            },
            keywords = listOf("maps", "map", "मैप्स", "मैप", "नक्शा", "रास्ता")
        )
    )

    fun findAppByVoiceCommand(command: String): AppTarget? {
        val lower = command.lowercase().trim()
        return supportedApps.firstOrNull { app ->
            app.keywords.any { keyword -> lower.contains(keyword) }
        }
    }

    fun isAppInstalled(packageName: String): Boolean {
        return try {
            context.packageManager.getPackageInfo(packageName, 0)
            true
        } catch (e: PackageManager.NameNotFoundException) {
            false
        }
    }

    fun launchApp(target: AppTarget): AppLaunchResult {
        val pm = context.packageManager

        // 1. Try primary package launch intent
        val primaryLaunchIntent = pm.getLaunchIntentForPackage(target.primaryPackage)
        if (primaryLaunchIntent != null) {
            primaryLaunchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(primaryLaunchIntent)
            return AppLaunchResult.Success(target.displayNameHindi, target.primaryPackage)
        }

        // 2. Try alternate packages
        for (alt in target.alternatePackages) {
            val altIntent = pm.getLaunchIntentForPackage(alt)
            if (altIntent != null) {
                altIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(altIntent)
                return AppLaunchResult.Success(target.displayNameHindi, alt)
            }
        }

        // 3. Try custom intentProvider (e.g. Settings, Dialer, Camera, Browser)
        val genericIntent = target.intentProvider?.invoke()
        if (genericIntent != null && genericIntent.resolveActivity(pm) != null) {
            context.startActivity(genericIntent)
            return AppLaunchResult.Success(target.displayNameHindi, target.primaryPackage)
        }

        // 4. App not installed
        return AppLaunchResult.NotInstalled(target.displayNameHindi, target.primaryPackage)
    }

    fun openPlayStore(packageName: String) {
        val playStoreIntent = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$packageName")).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            context.startActivity(playStoreIntent)
        } catch (e: Exception) {
            val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$packageName")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(webIntent)
        }
    }

    fun getQuickAppsList(): List<QuickAppItem> {
        return supportedApps.map { app ->
            val installed = isAppInstalled(app.primaryPackage) ||
                    (app.intentProvider != null && app.intentProvider.invoke().resolveActivity(context.packageManager) != null)
            QuickAppItem(
                id = app.id,
                nameHindi = app.displayNameHindi,
                nameEnglish = app.displayNameEnglish,
                packageName = app.primaryPackage,
                isInstalled = installed
            )
        }
    }
}
