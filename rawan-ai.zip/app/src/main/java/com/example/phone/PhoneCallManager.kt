package com.example.phone

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.net.Uri
import android.provider.ContactsContract
import androidx.core.content.ContextCompat

data class CallTarget(
    val displayName: String,
    val phoneNumber: String,
    val isDirectNumber: Boolean = false
)

class PhoneCallManager(private val context: Context) {

    fun parseCallTarget(command: String): CallTarget? {
        val normalized = normalizeHindiNumerals(command.trim())

        // 1. Check for explicit phone number in command (e.g., '9876543210 par call karo')
        val numberRegex = Regex("""(\+?\d[\d\s\-]{7,14}\d)""")
        val numberMatch = numberRegex.find(normalized)
        if (numberMatch != null) {
            val rawNum = numberMatch.value.replace(Regex("""[\s\-]"""), "")
            if (rawNum.length >= 7) {
                return CallTarget(
                    displayName = rawNum,
                    phoneNumber = rawNum,
                    isDirectNumber = true
                )
            }
        }

        // 2. Check for contact name (e.g., 'Papa ko call lagao', 'Mummy ko phone karo', 'Ramesh ko call milaao')
        val callKeywords = listOf(
            "call lagao", "call karo", "call milaao", "call milao", "phone lagao", "phone karo",
            "कॉल लगाओ", "कॉल करो", "कॉल मिलाओ", "फ़ोन लगाओ", "फोन लगाओ", "फ़ोन करो", "फोन करो", "कॉल"
        )

        var queryTarget = ""
        for (kw in callKeywords) {
            val idx = normalized.lowercase().indexOf(kw)
            if (idx != -1) {
                // E.g. "Papa ko call lagao" -> before kw is "Papa ko "
                val before = normalized.substring(0, idx).trim()
                if (before.isNotBlank()) {
                    queryTarget = before.replace(Regex("""(?i)\b(ko|pe|par|ko\s+bhi|को|पर)\b"""), "").trim()
                    break
                }
                // E.g. "call lagao Papa ko" -> after kw is " Papa ko"
                val after = normalized.substring(idx + kw.length).trim()
                if (after.isNotBlank()) {
                    queryTarget = after.replace(Regex("""(?i)\b(ko|pe|par|ko\s+bhi|को|पर)\b"""), "").trim()
                    break
                }
            }
        }

        if (queryTarget.isNotBlank()) {
            // Search contact in address book
            val foundContact = searchContact(queryTarget)
            return if (foundContact != null) {
                foundContact
            } else {
                // Return queryTarget with empty number so UI/Rawan can ask user for number or dialer
                CallTarget(
                    displayName = queryTarget,
                    phoneNumber = "",
                    isDirectNumber = false
                )
            }
        }

        return null
    }

    private fun searchContact(targetName: String): CallTarget? {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            return null
        }

        val uri: Uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER
        )
        val selection = "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?"
        val selectionArgs = arrayOf("%$targetName%")

        var cursor: Cursor? = null
        try {
            cursor = context.contentResolver.query(uri, projection, selection, selectionArgs, null)
            if (cursor != null && cursor.moveToFirst()) {
                val nameIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                val numberIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                val name = cursor.getString(nameIndex)
                val number = cursor.getString(numberIndex)
                if (!number.isNullOrBlank()) {
                    return CallTarget(
                        displayName = name ?: targetName,
                        phoneNumber = number.replace(Regex("""[\s\-]"""), ""),
                        isDirectNumber = false
                    )
                }
            }
        } catch (e: Exception) {
            // Permission or cursor exception
        } finally {
            cursor?.close()
        }

        return null
    }

    fun openDialer(phoneNumber: String) {
        val cleanNumber = phoneNumber.replace(Regex("""[^\d\+]"""), "")
        val dialUri = if (cleanNumber.isNotBlank()) {
            Uri.parse("tel:$cleanNumber")
        } else {
            Uri.parse("tel:")
        }
        val dialIntent = Intent(Intent.ACTION_DIAL, dialUri).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(dialIntent)
    }

    private fun normalizeHindiNumerals(text: String): String {
        return text
            .replace('०', '0')
            .replace('१', '1')
            .replace('२', '2')
            .replace('३', '3')
            .replace('४', '4')
            .replace('५', '5')
            .replace('६', '6')
            .replace('७', '7')
            .replace('८', '8')
            .replace('९', '9')
    }
}
