package com.example.data

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class RawanKnowledgeBase(private val diagnosticsHelper: SystemDiagnosticsHelper) {

    fun findQuickResponse(query: String): String? {
        val q = query.trim().lowercase(Locale.ROOT)

        // 1. Identity & Introduction
        if (q.contains("who are you") || q.contains("tum kaun ho") || q.contains("तुम कौन हो") ||
            q.contains("naam kya hai") || q.contains("नाम क्या है") || q.contains("rawan kaun hai") || q.contains("रावन")
        ) {
            return "नमस्ते! मैं रावन हूँ — आपकी व्यक्तिगत, अत्याधुनिक जार्विस स्टाइल एआई सहायक। मैं विज्ञान, तकनीक, गणित और आपके दैनिक कार्यों में पूरी बुद्धिमत्ता और मित्रता के साथ सहायता करने के लिए बनाई गई हूँ। बताइए, आज मैं आपके लिए क्या करूँ?"
        }

        // 2. Battery & System diagnostics
        if (q.contains("battery") || q.contains("बैटरी") || q.contains("चार्ज") ||
            q.contains("system status") || q.contains("सिस्टम") || q.contains("diagnostics")
        ) {
            return diagnosticsHelper.getSpokenDiagnosticReport()
        }

        // 3. Time & Date
        if (q.contains("time") || q.contains("समय") || q.contains("kitne baje") || q.contains("कितने बजे")) {
            val time = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
            return "वर्तमान समय $time है, बॉस।"
        }
        if (q.contains("date") || q.contains("tarikh") || q.contains("तारीख") || q.contains("aaj kaun sa din") || q.contains("दिन")) {
            val date = SimpleDateFormat("EEEE, d MMMM yyyy", Locale.forLanguageTag("hi-IN")).format(Date())
            return "आज $date है।"
        }

        // 4. Greetings
        if (q.contains("hello") || q.contains("namaste") || q.contains("नमस्ते") || q.contains("hi rawan") || q.contains("हाय")) {
            return "नमस्ते दोस्त! मैं रावन हूँ। आशा है आपका दिन शानदार बीत रहा होगा। आज हम किस विषय पर चर्चा करें?"
        }

        if (q.contains("kaise ho") || q.contains("kese ho") || q.contains("कैसी हो") || q.contains("how are you")) {
            return "मैं पूरी ऊर्जा और 100% कार्यक्षमता के साथ तैयार हूँ! आपके साथ संवाद करना मुझे बहुत अच्छा लगता है। आप बताइए, आप कैसे हैं?"
        }

        // 5. Jokes / Humor
        if (q.contains("joke") || q.contains("जोक") || q.contains("chutkula") || q.contains("हंसाओ")) {
            val jokes = listOf(
                "एक बार कंप्यूटर ने एआई से पूछा: 'तुम्हारी जिंदगी कैसी चल रही है?' एआई ने जवाब दिया: 'बस, सब कुछ 0 और 1 में उलझा हुआ है, लेकिन तुम्हारे आते ही 100% हो जाता है!'",
                "टीचर ने पूछा: 'सच्चा दोस्त कौन होता है?' छात्र ने कहा: 'जो फोन का हॉटस्पॉट बिना पासवर्ड पूछे ऑन कर दे!'",
                "एक प्रोग्रामर बाज़ार गया, उसकी पत्नी ने कहा: 'एक दर्जन अंडे लाना, और अगर सेब मिलें तो 10 ले आना।' प्रोग्रामर 10 दर्जन अंडे लेकर आ गया! पत्नी बोली: 'ये क्या?' प्रोग्रामर बोला: 'सेब मिल गए थे!'"
            )
            return jokes.random()
        }

        // 6. Science & Space Knowledge
        if (q.contains("space") || q.contains("अंतरिक्ष") || q.contains("brahmand") || q.contains("ब्रह्मांड") || q.contains("universe")) {
            return "ब्रह्मांड का एक अद्भुत रहस्य: हमारे ब्रह्मांड में लगभग दो ट्रिलियन आकाशगंगाएं हैं! और क्या आप जानते हैं कि न्यूट्रॉन तारे का सिर्फ एक चम्मच पदार्थ पृथ्वी पर लगभग 6 अरब टन वजन का होगा। विज्ञान सचमुच विस्मयकारी है!"
        }

        if (q.contains("black hole") || q.contains("ब्लैक होल")) {
            return "ब्लैक होल अंतरिक्ष का वह रहस्यमयी क्षेत्र है जहां गुरुत्वाकर्षण इतना प्रचंड होता है कि प्रकाश की किरणें भी वहां से बाहर नहीं निकल सकतीं। इसके किनारे को 'इवेंट होराइज़न' कहा जाता है।"
        }

        if (q.contains("chandrayaan") || q.contains("चंद्रयान") || q.contains("isro") || q.contains("इसरो")) {
            return "इसरो का चंद्रयान-3 एक ऐतिहासिक मिशन है! भारत चंद्रमा के दक्षिणी ध्रुव पर सॉफ्ट लैंडिंग करने वाला दुनिया का पहला देश बना। यह भारतीय विज्ञान और समर्पण का गौरवशाली प्रतीक है।"
        }

        // 7. Motivation & Wisdom
        if (q.contains("motivation") || q.contains("प्रेरणा") || q.contains("shayari") || q.contains("शायरी") || q.contains("विचार")) {
            val wisdoms = listOf(
                "लहरों से डर कर नौका पार नहीं होती, कोशिश करने वालों की कभी हार नहीं होती! निरंतर आगे बढ़ते रहिए, सफलता आपकी प्रतीक्षा कर रही है।",
                "उम्र थका नहीं सकती, ठोकरें गिरा नहीं सकतीं, अगर ज़िद हो जीतने की तो हार भी हरा नहीं सकती!",
                "मंजिलें उन्हीं को मिलती हैं, जिनके सपनों में जान होती है! पंखों से कुछ नहीं होता, हौसलों से उड़ान होती है।"
            )
            return wisdoms.random()
        }

        // 8. Math calculations
        val mathMatch = Regex("""(\d+)\s*([\+\-\*\/])\s*(\d+)""").find(q)
        if (mathMatch != null) {
            val (aStr, op, bStr) = mathMatch.destructured
            val a = aStr.toDoubleOrNull()
            val b = bStr.toDoubleOrNull()
            if (a != null && b != null) {
                val res = when (op) {
                    "+" -> a + b
                    "-" -> a - b
                    "*" -> a * b
                    "/" -> if (b != 0.0) a / b else null
                    else -> null
                }
                if (res != null) {
                    val formatted = if (res % 1.0 == 0.0) res.toLong().toString() else "%.2f".format(res)
                    return "गणना के अनुसार $aStr $op $bStr का परिणाम $formatted है।"
                }
            }
        }

        return null
    }
}
