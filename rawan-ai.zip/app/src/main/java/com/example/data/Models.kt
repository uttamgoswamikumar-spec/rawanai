package com.example.data

enum class MessageSender {
    USER,
    RAWAN
}

data class RawanMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val sender: MessageSender,
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isVoice: Boolean = false,
    val isSpeaking: Boolean = false
)

data class TelemetryData(
    val batteryPercent: Int = 100,
    val isCharging: Boolean = false,
    val availableRamMb: Long = 0L,
    val isOnline: Boolean = true,
    val systemTime: String = "",
    val statusText: String = "ACTIVE"
)
