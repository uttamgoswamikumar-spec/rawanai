package com.example.data

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class SystemDiagnosticsHelper(private val context: Context) {

    fun getTelemetry(): TelemetryData {
        val (batteryPct, isCharging) = getBatteryInfo()
        val availRam = getAvailableRamMb()
        val online = isNetworkAvailable()
        val timeStr = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())

        return TelemetryData(
            batteryPercent = batteryPct,
            isCharging = isCharging,
            availableRamMb = availRam,
            isOnline = online,
            systemTime = timeStr,
            statusText = if (online) "ONLINE" else "LOCAL_MODE"
        )
    }

    private fun getBatteryInfo(): Pair<Int, Boolean> {
        return try {
            val intentFilter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            val batteryStatus = context.registerReceiver(null, intentFilter)
            val level = batteryStatus?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = batteryStatus?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
            val status = batteryStatus?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                    status == BatteryManager.BATTERY_STATUS_FULL
            val pct = if (level >= 0 && scale > 0) {
                ((level / scale.toFloat()) * 100).toInt()
            } else 100
            Pair(pct, isCharging)
        } catch (e: Exception) {
            Pair(100, false)
        }
    }

    private fun getAvailableRamMb(): Long {
        return try {
            val actManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val memInfo = ActivityManager.MemoryInfo()
            actManager.getMemoryInfo(memInfo)
            memInfo.availMem / (1024 * 1024)
        } catch (e: Exception) {
            1024L
        }
    }

    private fun isNetworkAvailable(): Boolean {
        return try {
            val connMgr = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val activeNetwork = connMgr.activeNetwork ?: return false
            val cap = connMgr.getNetworkCapabilities(activeNetwork) ?: return false
            cap.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        } catch (e: Exception) {
            true
        }
    }

    fun getSpokenDiagnosticReport(): String {
        val telemetry = getTelemetry()
        val chargingText = if (telemetry.isCharging) "चार्ज हो रहा है" else "डिस्चार्जिंग मोड में है"
        return "बॉस, सिस्टम डायग्नोस्टिक्स पूरी तरह सामान्य है। आपकी बैटरी ${telemetry.batteryPercent} प्रतिशत है और $chargingText। उपलब्ध रैम ${telemetry.availableRamMb} मेगाबाइट है। इंटरनेट कनेक्टिविटी सक्रिय है। मैं हर आदेश के लिए तैयार हूँ!"
    }
}
