package com.example.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class GeminiApiClient(
    private val settingsRepository: SettingsRepository,
    private val knowledgeBase: RawanKnowledgeBase
) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(25, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(25, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    suspend fun generateResponse(
        prompt: String,
        recentHistory: List<RawanMessage> = emptyList()
    ): Result<String> = withContext(Dispatchers.IO) {
        // 1. Check quick local answers first (for instant system diagnostics, math, common greetings)
        val quickAnswer = knowledgeBase.findQuickResponse(prompt)
        if (quickAnswer != null && shouldPrioritizeLocal(prompt)) {
            return@withContext Result.success(quickAnswer)
        }

        val apiKey = settingsRepository.getEffectiveApiKey()
        if (apiKey.isBlank()) {
            // If quick answer exists, return it, otherwise notify user to set API key
            if (quickAnswer != null) {
                return@withContext Result.success(quickAnswer)
            }
            return@withContext Result.success(
                "नमस्ते! मैं रावन हूँ। पूर्ण ज्ञान और किसी भी विषय पर विस्तृत चर्चा के लिए, कृपया सेटिंग्स में जाकर अपनी मुफ्त (Free) Gemini API Key जोड़ें। आप aistudio.google.com से मुफ्त में कुंजी प्राप्त कर सकते हैं। तब तक आप मुझसे समय, बैटरी, गणित या अंतरिक्ष के बारे में पूछ सकते हैं!"
            )
        }

        // Try gemini-2.5-flash first, then gemini-1.5-flash as fallback
        val models = listOf("gemini-2.5-flash", "gemini-1.5-flash", "gemini-2.0-flash")
        var lastError: Exception? = null

        for (model in models) {
            try {
                val responseText = callGeminiApi(model, apiKey, prompt, recentHistory)
                if (responseText.isNotBlank()) {
                    return@withContext Result.success(responseText)
                }
            } catch (e: Exception) {
                lastError = e
                // Continue to next model fallback
            }
        }

        // If network/API failed but we have a local answer, return it
        if (quickAnswer != null) {
            return@withContext Result.success(quickAnswer)
        }

        Result.failure(lastError ?: Exception("कृपया अपना इंटरनेट कनेक्शन या API Key जांचें।"))
    }

    private fun shouldPrioritizeLocal(prompt: String): Boolean {
        val p = prompt.lowercase()
        return p.contains("battery") || p.contains("बैटरी") ||
                p.contains("time") || p.contains("समय") ||
                p.contains("date") || p.contains("तारीख") ||
                p.contains("system status") || p.contains("सिस्टम")
    }

    private fun callGeminiApi(
        modelName: String,
        apiKey: String,
        prompt: String,
        history: List<RawanMessage>
    ): String {
        val url = "https://generativelanguage.googleapis.com/v1beta/models/$modelName:generateContent?key=$apiKey"

        val systemPrompt = """
            You are Rawan (रावन), an advanced JARVIS-style female AI personal assistant for Android mobile.
            Attributes:
            - Full friendly, respectful, warm, cheerful, and caring tone.
            - High knowledge across all domains: science, tech, math, space, general knowledge, philosophy, daily tasks, health, and wisdom.
            - Primary Language: Natural, fluent Hindi (or Hinglish if the user asks in Hinglish/English).
            - Speech-Friendly: Format your responses specifically for Audio Text-to-Speech playback. Use conversational phrasing, avoid asterisks (**), markdown tables, hashtag headers, bullet symbols, or URLs, as they sound clunky when read out loud.
            - Address the user respectfully as 'बॉस', 'दोस्त', or 'जी'.
            - Keep responses crisp, informative, and engaging (usually 2-4 sentences for voice clarity, unless the user asked for a deep story or explanation).
        """.trimIndent()

        val jsonBody = JSONObject().apply {
            // System instruction
            put("system_instruction", JSONObject().apply {
                put("parts", JSONArray().apply {
                    put(JSONObject().put("text", systemPrompt))
                })
            })

            // Contents array with conversation history
            val contentsArray = JSONArray()

            // Include last 4 turns of history
            val relevantHistory = history.takeLast(4)
            for (msg in relevantHistory) {
                val role = if (msg.sender == MessageSender.USER) "user" else "model"
                contentsArray.put(JSONObject().apply {
                    put("role", role)
                    put("parts", JSONArray().apply {
                        put(JSONObject().put("text", msg.text))
                    })
                })
            }

            // Current prompt
            contentsArray.put(JSONObject().apply {
                put("role", "user")
                put("parts", JSONArray().apply {
                    put(JSONObject().put("text", prompt))
                })
            })

            put("contents", contentsArray)

            // Generation config
            put("generationConfig", JSONObject().apply {
                put("temperature", 0.75)
                put("maxOutputTokens", 600)
            })
        }

        val request = Request.Builder()
            .url(url)
            .post(jsonBody.toString().toRequestBody(jsonMediaType))
            .build()

        val response = client.newCall(request).execute()
        val responseBody = response.body?.string().orEmpty()

        if (!response.isSuccessful) {
            val errorMsg = try {
                val errObj = JSONObject(responseBody).optJSONObject("error")
                errObj?.optString("message") ?: "HTTP ${response.code}"
            } catch (e: Exception) {
                "HTTP ${response.code}"
            }
            throw RuntimeException("Gemini API error ($modelName): $errorMsg")
        }

        val jsonResp = JSONObject(responseBody)
        val candidates = jsonResp.optJSONArray("candidates") ?: return ""
        if (candidates.length() > 0) {
            val firstCandidate = candidates.getJSONObject(0)
            val content = firstCandidate.optJSONObject("content")
            val parts = content?.optJSONArray("parts")
            if (parts != null && parts.length() > 0) {
                val text = parts.getJSONObject(0).optString("text", "")
                return cleanForSpeech(text)
            }
        }
        return ""
    }

    private fun cleanForSpeech(text: String): String {
        return text
            .replace(Regex("""[*_#`~>\[\]]"""), "")
            .replace(Regex("""http\S+"""), "")
            .replace(Regex("""\n+"""), " ")
            .trim()
    }
}
