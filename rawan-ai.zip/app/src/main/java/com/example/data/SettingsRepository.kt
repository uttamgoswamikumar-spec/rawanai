package com.example.data

import android.content.Context
import android.content.SharedPreferences
import com.example.BuildConfig

class SettingsRepository(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("rawan_ai_settings", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_API_KEY = "custom_gemini_api_key"
        private const val KEY_VOICE_PITCH = "voice_pitch"
        private const val KEY_VOICE_SPEED = "voice_speed"
        private const val KEY_CONTINUOUS_MODE = "continuous_mode"
        private const val KEY_TONE_STYLE = "tone_style"
    }

    fun getCustomApiKey(): String {
        return prefs.getString(KEY_API_KEY, "") ?: ""
    }

    fun setCustomApiKey(key: String) {
        prefs.edit().putString(KEY_API_KEY, key.trim()).apply()
    }

    fun getEffectiveApiKey(): String {
        val customKey = getCustomApiKey()
        if (customKey.isNotBlank()) return customKey

        // Fallback to BuildConfig if provided via secrets/.env
        return try {
            val buildConfigKey = BuildConfig.GEMINI_API_KEY
            if (buildConfigKey.isNotBlank() &&
                buildConfigKey != "YOUR_GEMINI_API_KEY" &&
                buildConfigKey != "MY_GEMINI_API_KEY"
            ) buildConfigKey else ""
        } catch (e: Throwable) {
            ""
        }
    }

    fun getVoicePitch(): Float {
        return prefs.getFloat(KEY_VOICE_PITCH, 1.15f)
    }

    fun setVoicePitch(pitch: Float) {
        prefs.edit().putFloat(KEY_VOICE_PITCH, pitch).apply()
    }

    fun getVoiceSpeed(): Float {
        return prefs.getFloat(KEY_VOICE_SPEED, 1.0f)
    }

    fun setVoiceSpeed(speed: Float) {
        prefs.edit().putFloat(KEY_VOICE_SPEED, speed).apply()
    }

    fun isContinuousMode(): Boolean {
        return prefs.getBoolean(KEY_CONTINUOUS_MODE, false)
    }

    fun setContinuousMode(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_CONTINUOUS_MODE, enabled).apply()
    }

    fun getToneStyle(): String {
        return prefs.getString(KEY_TONE_STYLE, "FRIENDLY") ?: "FRIENDLY"
    }

    fun setToneStyle(style: String) {
        prefs.edit().putString(KEY_TONE_STYLE, style).apply()
    }
}
